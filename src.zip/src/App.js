import "./App.css";
import Profile from "./pages/Profile";
import SignUp from "./pages/SignUp";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ItemList from "./pages/ItemList";

function App() {
  return (
    <>
      <Profile />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SignUp />} />
          <Route path="/items" element={<ItemList />} />
        </Routes>
      </BrowserRouter>

      {/* <SignUp /> */}
    </>
  );
}

export default App;
