import { createSlice } from "@reduxjs/toolkit";
const cartInitialState = [];

export const cartSlice = createSlice({
  name: "cart",
  initialState: cartInitialState,
  reducers: {
    addToCart: {
      reducer(state, action) {
        const newItem = action.payload;
        const quantity = 0;
        const existingItemIndex = state.findIndex(
          (item) => item.newItem.id === newItem.id
        );
        if (existingItemIndex !== -1) {
          // console.log("ooooooooooooooooooooo", state[existingItemIndex]);
          state[existingItemIndex].newItem = newItem;
          state[existingItemIndex].quantity += 1;
        } else {
          state.push({ newItem, quantity: 1 });
        }
        // const newId = action.payload.id;
      },
    },
  },
});

export const { addToCart } = cartSlice.actions;
export default cartSlice.reducer;
