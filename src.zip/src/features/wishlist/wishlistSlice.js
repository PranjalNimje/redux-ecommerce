export const wishlist = [
  {
    itemID: null,
    itemName: "",
  },
];
