import React, { useState } from "react";
import { useData } from "../hooks/useData";
import Login from "./Login";

const SignUp = () => {
  const { name, setName, email, setEmail, handleSubmit } = useData();
  const [showLogin, setShowLogin] = useState(false);
  return (
    <>
      {showLogin ? (
        <Login />
      ) : (
        <>
          <div
            style={{
              display: "grid",
              margin: "auto",
              width: "fit-content",
              padding: "4rem",
              border: "2px solid GAINSBORO",
              borderRadius: "5px",
            }}
          >
            {" "}
            <h1>SignUp</h1>
            <input
              type="text"
              placeholder="Username"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <input
              type="text"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button onClick={handleSubmit}>Submit</button>
            <span> Already a member ? </span>
            <button onClick={() => setShowLogin(true)}>Login</button>
          </div>
        </>
      )}
    </>
  );
};

export default SignUp;
