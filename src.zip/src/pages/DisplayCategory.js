import React from "react";
import { useCategory } from "../hooks/useCategory";

const DisplayCategory = () => {
  const { categories } = useCategory();
  return <div>{}</div>;
};

export default DisplayCategory;
