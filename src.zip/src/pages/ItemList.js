import React, { useCallback } from "react";
import { useDispatch, useSelector, connect } from "react-redux";
import { addToCart } from "../features/cart/cartSlice";
import { useProductsList } from "../hooks/useProductsList";
import CategoryHeader from "./CategoryHeader";
import store from "../store/store";
// import {connect } from ""
const ItemList = () => {
  // console.log("Items", items);
  const { itemsList } = useProductsList();
  const dispatch = useDispatch();

  const handleAddToCart = (i) => {
    dispatch(addToCart(i));
  };

  const cart = useSelector((state) => state.cart);
  console.log("CART", cart);

  console.log("cart", store.getState());
  return (
    <>
      <CategoryHeader></CategoryHeader>
      <div
        style={{
          margin: "auto",
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {itemsList.map((i) => (
          <div
            key={i.id}
            style={{
              width: "200px",
              height: "200px",
              border: "1px solid grey",
              padding: "1rem",
              margin: "1rem",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-evenly",
              alignItems: "center",
            }}
          >
            <span>{i.title}</span>
            <span> {i.category}</span>
            <button onClick={() => handleAddToCart(i)}>Add to cart</button>
            {cart.length !== 0 &&
              cart.map((item) => {
                item.newItem.id === i.id && (
                  <span>{item.quantity} product added to cart</span>
                );
              })}
          </div>
        ))}
      </div>
    </>
  );
};

export default ItemList;
