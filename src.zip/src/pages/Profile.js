import React from "react";
import { useSelector } from "react-redux";
import { CgProfile } from "react-icons/cg";
import { FaUserLarge } from "react-icons/fa6";
import Cart from "./Cart";
// import AccountCircleIcon from "@mui/icons-material/AccountCircle";
// import account from "../assets/account";
const Profile = () => {
  const selectedUser = useSelector((state) => state.user.selectedUser);
  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          padding: "1rem",
          backgroundColor: "antiquewhite",
          position: "sticky",
          top: "8px",
        }}
      >
        {/* <div
          style={{
            // width: "22%",
            display: "flex",
            justifyContent: "space-between",
          }}
        > */}
        <span>
          Welcome
          {selectedUser.userName === ""
            ? ` Guest  `
            : ` ${selectedUser.userName}  `}
          {"  "}
          {/* </span> */}
          {/* <span> */}
          <FaUserLarge />
        </span>
        <span>
          <Cart />
        </span>
        {/* </div> */}
      </div>
    </>
  );
};

export default Profile;
