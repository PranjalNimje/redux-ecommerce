import React from "react";
import { useCategory } from "../hooks/useCategory";

const CategoryHeader = () => {
  const { categories } = useCategory();
  return (
    <div
      style={{
        display: "flex",
        backgroundColor: "aqua",
        justifyContent: "space-evenly",
        position: "sticky",
        top: "66px",
      }}
    >
      {categories.map((eachCategory) => (
        <div
          key={eachCategory}
          style={{
            margin: "0.4rem",
            padding: "0.4rem",
            border: "1px solid grey",
            cursor: "pointer",
          }}
        >
          {eachCategory}
        </div>
      ))}
    </div>
  );
};

export default CategoryHeader;
