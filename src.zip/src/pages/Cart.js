import React from "react";
import { FaShoppingCart } from "react-icons/fa";
import { useSelector } from "react-redux";

const Cart = () => {
  const cart = useSelector((state) => state.cart);
  console.log("cartlength", cart.length);
  return (
    <div style={{ display: "flex" }}>
      <FaShoppingCart />
      <div
        style={{
          fontSize: "small",
          border: "1px solid",
          borderRadius: "8px",
          padding: "1px 5px",
          marginTop: "8px",
        }}
      >
        {cart.length}
      </div>
    </div>
  );
};

export default Cart;
