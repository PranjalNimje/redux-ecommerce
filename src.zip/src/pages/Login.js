import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addSelectedUser } from "../features/users/userSlice";
import { useData } from "../hooks/useData";
import ItemList from "./ItemList";

const Login = () => {
  const [loginName, setLoginName] = useState("");
  const { currUser, setCurrUser } = useData();
  //   const { handleLogin } = useData();
  const dispatch = useDispatch();
  const allUsers = useSelector((state) => state.user.allUsers);
  const handleLogin = () => {
    console.log("allUsers", allUsers);
    const currentUser = allUsers.filter((ele) => ele.userName === loginName);
    setCurrUser(currentUser[0]);
    // console.log("currUser", currUser);
    dispatch(addSelectedUser(currentUser));
  };
  console.log("currUser", currUser);

  return (
    <>
      {Object.keys(currUser).length > 0 ? (
        <>
          <ItemList />
        </>
      ) : (
        <>
          <div
            style={{
              display: "grid",
              margin: "auto",
              width: "fit-content",
              padding: "4rem",
              border: "2px solid GAINSBORO",
              borderRadius: "5px",
            }}
          >
            <h1>Login</h1>
            <input
              type="text"
              placeholder="Username"
              value={loginName}
              onChange={(e) => setLoginName(e.target.value)}
            />
            <button onClick={handleLogin}>Login</button>
          </div>
        </>
      )}
    </>
  );
};

export default Login;
